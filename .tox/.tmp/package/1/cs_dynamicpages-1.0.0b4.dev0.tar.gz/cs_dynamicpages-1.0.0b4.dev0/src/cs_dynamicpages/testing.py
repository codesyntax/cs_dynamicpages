from plone.app.contenttypes.testing import PLONE_APP_CONTENTTYPES_FIXTURE
from plone.app.robotframework.testing import REMOTE_LIBRARY_BUNDLE_FIXTURE
from plone.app.testing import applyProfile
from plone.app.testing import FunctionalTesting
from plone.app.testing import IntegrationTesting
from plone.app.testing import PloneSandboxLayer
from plone.testing.zope import WSGI_SERVER_FIXTURE

import cs_dynamicpages


class Layer(PloneSandboxLayer):
    defaultBases = (PLONE_APP_CONTENTTYPES_FIXTURE,)

    def setUpZope(self, app, configurationContext):
        # Load any other ZCML that is required for your tests.
        # The z3c.autoinclude feature is disabled in the Plone fixture base
        # layer.
        self.loadZCML(package=cs_dynamicpages)

    def setUpPloneSite(self, portal):
        applyProfile(portal, "cs_dynamicpages:default")


FIXTURE = Layer()

INTEGRATION_TESTING = IntegrationTesting(
    bases=(FIXTURE,),
    name="CsDynamicpagesLayer:IntegrationTesting",
)


FUNCTIONAL_TESTING = FunctionalTesting(
    bases=(FIXTURE, WSGI_SERVER_FIXTURE),
    name="CsDynamicpagesLayer:FunctionalTesting",
)


ACCEPTANCE_TESTING = FunctionalTesting(
    bases=(
        FIXTURE,
        REMOTE_LIBRARY_BUNDLE_FIXTURE,
        WSGI_SERVER_FIXTURE,
    ),
    name="CsDynamicpagesLayer:AcceptanceTesting",
)

# Aliases for backward compatibility with bobtemplates.plone naming
CS_DYNAMICPAGES_INTEGRATION_TESTING = INTEGRATION_TESTING
CS_DYNAMICPAGES_FUNCTIONAL_TESTING = FUNCTIONAL_TESTING
CS_DYNAMICPAGES_ACCEPTANCE_TESTING = ACCEPTANCE_TESTING
